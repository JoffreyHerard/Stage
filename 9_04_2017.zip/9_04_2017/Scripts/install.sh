#!/bin/bash

sudo apt-get install phoronix-test-suite