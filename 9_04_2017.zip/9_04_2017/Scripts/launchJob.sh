#!/bin/bash

phoronix-test-suite batch-benchmark $1
